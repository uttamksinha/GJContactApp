//
//  GJContactListViewController.swift
//  GoJekContactApp
//
//  Created by EHT4-MacAir2 on 13/07/19.
//  Copyright © 2019 Uttam. All rights reserved.
//

import UIKit

class GJContactListViewController: UITableViewController {

    var contactViewModel = GJContactViewModel()
    var arrIndexSection : [String] = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Contact"
        showLoader(self)
        GJNetworkService.fetchData(completion: { //closure
            contactVM in
            self.contactViewModel.arrContactList = contactVM
            DispatchQueue.main.async {
                hideLoader()
                if self.contactViewModel.arrContactList.count > 0 {
                    self.tableView.reloadData()
                }
            }
        })
    }
  

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        if self.contactViewModel.arrContactList.count > 0 {
            return arrIndexSection.count
        }
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return contactViewModel.arrContactList.count
    }
    
    override func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        if self.contactViewModel.arrContactList.count > 0 {
        return arrIndexSection
        }
        return [""]
    }
    
    override func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
        return index
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return arrIndexSection[section]
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "GJContactListViewCell", for: indexPath) as! GJContactListViewCell
        
        let model:GJContactModel = contactViewModel.arrContactList[indexPath.row]

        cell.profileImageView.load(url: URL(string: model.profilePic!)!)
        cell.contactName.text = model.firstName! + " " + model.lastName!
        if model.favorite! {
            cell.favouriteImageView.image = UIImage(named:"FavouriteButtonSelected")
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        getting the index path of selected row
        let indexPath = tableView.indexPathForSelectedRow

        //getting the current cell from the index path
        //let currentCell = tableView.cellForRow(at: indexPath!)! as! GJContactListViewCell
        
        let model:GJContactModel = contactViewModel.rowContactData(index: indexPath!.row)
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let detailViewController = storyBoard.instantiateViewController(withIdentifier: "GJContactDetailViewController") as! GJContactDetailViewController
        detailViewController.contactModel = model
        self.navigationController?.pushViewController(detailViewController, animated: true)
    }

}

extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}

//
//  GJContactViewModel.swift
//  GoJekContactApp
//
//  Created by EHT4-MacAir2 on 14/07/19.
//  Copyright © 2019 Uttam. All rights reserved.
//

import UIKit

class GJContactViewModel: NSObject {
    
        var arrContactList:[GJContactModel] = []
        
        func numberofRowsInTable() -> Int {
            return arrContactList.count
        }
        
        func rowContactData(index:Int) -> GJContactModel {
            return arrContactList[index]
        }

}

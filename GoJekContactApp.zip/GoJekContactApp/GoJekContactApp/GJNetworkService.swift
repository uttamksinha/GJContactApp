//
//  GJNetworkService.swift
//  GoJekContactApp
//
//  Created by EHT4-MacAir2 on 14/07/19.
//  Copyright © 2019 Uttam. All rights reserved.
//

import Foundation

class GJNetworkService {
    
    static let baseURL = "https://gojek-contacts-app.herokuapp.com"
    
    static func fetchData(completion:@escaping ([GJContactModel])->()) {
        
        let url = URL(string: baseURL + "/contacts.json")!
        var request = URLRequest(url: url)
        let session = URLSession(configuration: .default)
        request.httpMethod = "GET"
        
        session.dataTask(with: request) { (data, response, error) in
            
            
            if  let data = data {
                do {
                    var model:[GJContactModel]=[]
                    let json = try JSONDecoder().decode([JsonData].self , from: data)
                    for item in json {
                        model.append(GJContactModel(id: item.id, firstName: item.firstName, lastName: item.lastName, profilePic: item.profilePic, favorite: item.favorite, url: item.url))
                    }
                    completion(model)
                } catch {
                    print("Error found:\(error)")
                    
                }
            }
        }.resume()
    }
    
    static func fetchContact(id:Int, completion:@escaping (GJContactModel)->()){
        let url = URL(string: baseURL + "/contacts/\(id).json")!
        var request = URLRequest(url: url)
        let session = URLSession(configuration: .default)
        request.httpMethod = "GET"
        
        session.dataTask(with: request) { (data, response, error) in
            
            
            if  let data = data {
                do {
                    let json = try JSONDecoder().decode(JsonData.self , from: data)
                    completion(GJContactModel(id: json.id, firstName: json.firstName, lastName: json.lastName, profilePic: json.profilePic, favorite: json.favorite, url: json.url))
                } catch {
                    print("Error found:\(error)")
                    
                }
            }
            }.resume()
    }
    
    static func addContact(value:[String:String], completion:@escaping (String)->()){
        let url = URL(string: baseURL + "/contacts.json")!
        do {
        let jsonData = try JSONEncoder().encode(value)
        var request = URLRequest(url: url)
        let session = URLSession(configuration: .default)
        request.httpMethod = "POST"
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        session.dataTask(with: request) { (data, response, error) in
            if let data = data {
            let responseString = String(data:data, encoding: .utf8)
            print("responseString = \(String(describing: responseString))")
            completion("Contact added successfully")
            }
        }.resume()
        }
        catch {
            print(error.localizedDescription)
        }
    }
    
    
    static func updateContact(id:Int, value:[String:String], completion:@escaping (String)->()){
        let url = URL(string: baseURL + "/contacts/\(id).json")!
        do {
        let jsonData = try JSONEncoder().encode(value)
        var request = URLRequest(url: url)
        let session = URLSession(configuration: .default)
        request.httpMethod = "PUT"
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        session.dataTask(with: request) { (data, response, error) in
            if let data = data {
                let responseString = String(data:data, encoding: .utf8)
                print("responseString = \(String(describing: responseString))")
                completion("Contact updated successfully")
            }
        }.resume()
        }
        catch {
            print(error.localizedDescription)
        }
    }
    
}

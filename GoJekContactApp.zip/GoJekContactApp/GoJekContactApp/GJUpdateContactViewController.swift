//
//  GJUpdateContactViewController.swift
//  GoJekContactApp
//
//  Created by EHT4-MacAir2 on 14/07/19.
//  Copyright © 2019 Uttam. All rights reserved.
//

import UIKit

enum State {
    case add
    case edit
}

class GJUpdateContactViewController: UIViewController {
    
    public var state = State.add
    private var firstName:String?
    private var lastName:String?
    private var email:String?
    private var mobile:String?
    public var contactModel:GJContactModel!
    
    
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let cancelBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(cancelButton))
        self.navigationItem.leftBarButtonItem  = cancelBarButtonItem
        
        let doneBarButtonItem = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButton))
        self.navigationItem.rightBarButtonItem  = doneBarButtonItem
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        
        view.addGestureRecognizer(tap)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        switch state {
        case .add:
            firstNameTextField.text = ""
            lastNameTextField.text = ""
        case .edit:
            if let model = contactModel {
                firstNameTextField.text = model.firstName
                lastNameTextField.text = model.lastName
            }
        }
    }
    
    //Calls this function when the tap is recognized.
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @objc func cancelButton(){
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func doneButton(){
        firstName = firstNameTextField.text!.count>0 ? firstNameTextField.text : ""
        lastName = lastNameTextField.text!.count>0 ? lastNameTextField.text : ""
        email = emailTextField.text!.count>0 ? emailTextField.text : ""
        mobile = phoneTextField.text!.count>0 ? phoneTextField.text : ""
        
        let dict = ["first_name" : firstName!,"last_name" : lastName!,"email" : email!,"phone_number" : mobile!];
        
        let json: [String: String] = dict
        
        switch state {
        case .edit:
            GJNetworkService.updateContact(id: contactModel.id!, value:json , completion: { //closure
                text in
                DispatchQueue.main.async {
                    self.showAlert(msg: text)            }
            })
        case .add:
            GJNetworkService.addContact(value:json , completion: { //closure
                text in
                DispatchQueue.main.async {
                    self.showAlert(msg: text)           }
            })
        }
    }
    
    func showAlert(msg:String) {
        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { _ in
            alert.dismiss(animated: true, completion: nil)
        }))
        self.present(alert, animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  GJContactListViewCell.swift
//  GoJekContactApp
//
//  Created by EHT4-MacAir2 on 13/07/19.
//  Copyright © 2019 Uttam. All rights reserved.
//

import UIKit

class GJContactListViewCell: UITableViewCell {

    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var contactName: UILabel!
    @IBOutlet weak var favouriteImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

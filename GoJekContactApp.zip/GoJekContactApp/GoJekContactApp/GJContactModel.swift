//
//  GJContactModel.swift
//  GoJekContactApp
//
//  Created by EHT4-MacAir2 on 14/07/19.
//  Copyright © 2019 Uttam. All rights reserved.
//

import Foundation

struct JsonData: Decodable {
    
    let id: Int
    let firstName, lastName: String
    let profilePic: String
    let favorite: Bool
    let url: String
    
    enum CodingKeys : String, CodingKey {
        case id
        case firstName = "first_name"
        case lastName = "last_name"
        case profilePic = "profile_pic"
        case favorite, url
    }
}

struct GJContactModel: Decodable {
    var id:Int?
    var firstName:String?
    var lastName: String?
    var profilePic: String?
    var favorite:Bool?
    var url:String?
}

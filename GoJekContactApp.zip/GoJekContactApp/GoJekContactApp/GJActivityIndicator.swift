//
//  GJActivityIndicator.swift
//  GoJekContactApp
//
//  Created by EHT4-MacAir2 on 15/07/19.
//  Copyright © 2019 Uttam. All rights reserved.
//

import Foundation
import UIKit

private let activityIndicator = UIActivityIndicatorView()

func showLoader(_ viewcontroller : UIViewController){
    DispatchQueue.main.async {
        activityIndicator.center = viewcontroller.view.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.style = .gray
        viewcontroller.view.addSubview(activityIndicator)
        activityIndicator.startAnimating()
        UIApplication.shared.beginIgnoringInteractionEvents()
    }
}

func hideLoader(){
    DispatchQueue.main.async {
        activityIndicator.stopAnimating()
        UIApplication.shared.endIgnoringInteractionEvents()
    }
}


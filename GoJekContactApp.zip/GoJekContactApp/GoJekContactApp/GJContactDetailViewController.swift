//
//  GJContactDetailViewController.swift
//  GoJekContactApp
//
//  Created by EHT4-MacAir2 on 13/07/19.
//  Copyright © 2019 Uttam. All rights reserved.
//

import UIKit

class GJContactDetailViewController: UIViewController {
    
    @IBOutlet weak var contactImageView: UIImageView!
    @IBOutlet weak var contactName: UILabel!
    @IBOutlet weak var favouriteBtn: UIButton!
    @IBOutlet weak var phoneLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    
    public var contactModel:GJContactModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let editBarButtonItem = UIBarButtonItem(barButtonSystemItem: .edit, target: self, action: #selector(editContact))
        self.navigationItem.rightBarButtonItem  = editBarButtonItem
    }
    
    @objc func editContact(){
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let updateViewController = storyBoard.instantiateViewController(withIdentifier: "GJUpdateContactViewController") as! GJUpdateContactViewController
        updateViewController.state = .edit
        updateViewController.contactModel = contactModel
        self.navigationController?.pushViewController(updateViewController, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        contactImageView.load(url: URL(string: contactModel.profilePic!)!)
        contactName.text = contactModel.firstName! + " " + contactModel.lastName!
        if contactModel.favorite! {
            favouriteBtn.imageView!.image = UIImage(named:"FavouriteButtonSelected")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
